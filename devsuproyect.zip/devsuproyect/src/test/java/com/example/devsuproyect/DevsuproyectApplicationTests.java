package com.example.devsuproyect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevsuproyectApplicationTests {

	@Test
	void contextLoads() {
	}

}
